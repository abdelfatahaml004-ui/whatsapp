
import 'package:flutter/material.dart';
import '../../core/widgets/message.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {

  final TextEditingController controller =
  TextEditingController();

  final List<Map<String, dynamic>> messages = [
    {
      'text': 'Hey! Have you ever thought about how random moments can sometimes turn into the best memories?',
      'isMe': false,
    },
    {
      'text': 'Yes! Life is full of surprises.',
      'isMe': true,
    },
    {
      'text': 'I totally agree!',
      'isMe': false,
    },
  ];

  void sendMessage() {
    if (controller.text.trim().isEmpty) return;

    setState(() {
      messages.add({
        'text': controller.text.trim(),
        'isMe': true,
      });

      controller.clear();
    });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF181818),

      appBar: AppBar(
        backgroundColor: const Color(0xFF168C4B),
        elevation: 0,
        leadingWidth: 90,

        leading: Row(
          children: [
            const SizedBox(width: 5),
            const Icon(Icons.arrow_back, color: Colors.white),
            const SizedBox(width: 8),
            const CircleAvatar(
              radius: 18,
              backgroundColor: Colors.white,
              child: Icon(
                Icons.person,
                color: Color(0xFF168C4B),
              ),
            ),
          ],
        ),

        title: const Text(
          'John Safwat',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
          ),
        ),

        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.call, color: Colors.white),
          ),

          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.videocam, color: Colors.white),
          ),

          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.more_vert, color: Colors.white),
          ),
        ],
      ),

      body: Column(
        children: [

          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(
                horizontal: 6,
                vertical: 12,
              ),

              itemCount: messages.length,

              itemBuilder: (context, index) {
                return MessageBubble(
                  message: messages[index]['text'],
                  isMe: messages[index]['isMe'],
                );
              },
            ),
          ),

          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 10,
            ),

            color: const Color(0xFF181818),

            child: Row(
              children: [

                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: const Color(0xFF168C4B),
                      ),
                      borderRadius: BorderRadius.circular(30),
                    ),

                    child: TextField(
                      controller: controller,

                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                      ),

                      onSubmitted: (_) => sendMessage(),

                      decoration: const InputDecoration(
                        hintText: 'Type a Message ...',

                        hintStyle: TextStyle(
                          color: Colors.white70,
                          fontSize: 12,
                        ),

                        border: InputBorder.none,

                        contentPadding: EdgeInsets.symmetric(
                          vertical: 14,
                        ),

                        prefixIcon: Icon(
                          Icons.camera_alt_outlined,
                          color: Colors.white,
                        ),

                        suffixIcon: Icon(
                          Icons.send,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),

                const SizedBox(width: 8),

                Container(
                  width: 48,
                  height: 48,

                  decoration: const BoxDecoration(
                    color: Color(0xFF168C4B),
                    shape: BoxShape.circle,
                  ),

                  child: IconButton(
                    onPressed: () {},
                    icon: const Icon(
                      Icons.mic,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
