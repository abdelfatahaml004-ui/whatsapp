
import 'package:flutter/material.dart';

import '../widgets/chat_app_bar.dart';
import '../widgets/message_bubble.dart';
import '../widgets/message_input.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController messageController =
  TextEditingController();

  final ScrollController scrollController =
  ScrollController();

  final List<Map<String, dynamic>> messages = [
    {'message': 'Hello !', 'isMe': false},
    {'message': 'Hello !', 'isMe': true},
    {
      'message':
      "Hey! Have you ever thought about how random moments can sometimes turn into the best memories? It's like the universe loves to surprise us when we least expect it!",
      'isMe': false,
    },
    {
      'message': 'what a Great Content Tp learn Flutter',
      'isMe': false,
    },
    {
      'message': 'what a Great Content Tp learn Flutter',
      'isMe': true,
    },
  ];

  void sendMessage() {
    String text = messageController.text.trim();

    if (text.isEmpty) return;

    setState(() {
      messages.add({
        'message': text,
        'isMe': true,
      });
    });

    messageController.clear();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scrollController.hasClients) {
        scrollController.animateTo(
          scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    messageController.dispose();
    scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF181818),

      appBar: const ChatAppBar(),

      body: Stack(
        children: [
          Positioned.fill(
            child: IgnorePointer(
              child: GridView.builder(
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate:
                const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 5,
                  mainAxisSpacing: 35,
                  crossAxisSpacing: 25,
                ),
                itemCount: 40,
                itemBuilder: (context, index) {
                  final icons = [
                    Icons.chat,
                    Icons.phone,
                    Icons.camera_alt,
                    Icons.star,
                    Icons.favorite,
                    Icons.send,
                    Icons.music_note,
                    Icons.photo,
                    Icons.emoji_emotions,
                    Icons.headphones,
                  ];

                  return Center(
                    child: Icon(
                      icons[index % icons.length],
                      color: Colors.white.withValues(alpha: 0.035),
                      size: 25,
                    ),
                  );
                },
              ),
            ),
          ),

          Column(
            children: [
              Expanded(
                child: ListView.builder(
                  controller: scrollController,
                  padding: const EdgeInsets.symmetric(
                    vertical: 12,
                  ),
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    return MessageBubble(
                      message: messages[index]['message'],
                      isMe: messages[index]['isMe'],
                    );
                  },
                ),
              ),

              MessageInput(
                controller: messageController,
                onSend: sendMessage,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
